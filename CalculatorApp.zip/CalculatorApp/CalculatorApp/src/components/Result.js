import React, { Component } from "react";
// creating a component for display the result
class Result extends Component {
  render() {
    return (
      <div className="result">
        <p>{this.props.result}</p>
      </div>
    );
  }
}
export default Result;
